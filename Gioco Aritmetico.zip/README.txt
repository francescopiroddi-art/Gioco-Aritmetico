Il Gioco di Aritmetica è un'applicazione educativa e divertente pensata per allenare le abilità matematiche. Il giocatore deve risolvere rapidamente operazioni aritmetiche (addizione, sottrazione, moltiplicazione e divisione) proposte in modo casuale.

Ogni risposta corretta aggiunge punti pari al risultato dell’operazione.

Le risposte sbagliate non penalizzano, ma non aggiungono punti.

Al raggiungimento di 1000 punti, si passa al livello successivo, e il punteggio viene moltiplicato per 10.

Il tempo impiegato per ogni livello viene tracciato.

Il record di punteggio massimo viene aggiornato in tempo reale durante la sessione.

L'interfaccia è semplice, intuitiva e basata su Tkinter, con pulsanti Start e Stop per gestire il gioco in ogni momento.